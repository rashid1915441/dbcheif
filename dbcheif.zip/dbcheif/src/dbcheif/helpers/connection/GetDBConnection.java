/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbcheif.helpers.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import dbcheif.interfaces.connector.Connector;

/**
 *
 * @author Rashid Iqbal
 */
public class GetDBConnection {

    private static Connection connection;
//    private static String host, port, db, dbuser, dbpassword, db_url;

    /**
     *
     * @param host
     * @param port
     * @param db
     * @param dbuser
     * @param dbpassword
     * @return
     */
    public static Connection get(String host, String port, String db, String dbuser, String dbpassword) {
        if (connection == null) {

            DBConnection dbConnection = new DBConnection();
            connection = dbConnection.getDbConnection(host, port, db, dbuser, dbpassword);
        }
        return connection;
    }

    static class DBConnection implements Connector {

        private static DBConnection dbInstance;
        private static DBConnection dbObj;

        Connection connection = null;

        private String host, port, db, dbuser, dbpassword, db_url;

        private DBConnection() {
            this.host = "";
            this.port = "";
            this.dbuser = "";
            this.dbpassword = "";
            this.db_url = "";
        }

        private static DBConnection getLocalObject() {
            if (dbObj == null) {
                dbObj = new DBConnection();
            }
            return dbObj;
        }

        @Override
        public DBConnection getInstance() {

            if (dbInstance == null) {
                dbInstance = new DBConnection();
            }
            return dbInstance;

        }

        public static DBConnection getGlobalInstance() {
            return getLocalObject().getInstance();
        }

        @Override
        public Connection getDbConnection(String host, String port, String db, String dbuser, String dbpassword) {

            this.host = host;
            this.port = port;
            this.db = db;
            this.dbuser = dbuser;
            this.dbpassword = dbpassword;

            this.db_url = "jdbc:mysql://" + this.host + ":" + this.port + "/" + this.db;

            if (connection == null) {

                try {
                    Class.forName("com.mysql.jdbc.Driver");

                    connection = DriverManager.getConnection(this.db_url, this.dbuser, this.dbpassword);
                } catch (ClassNotFoundException | SQLException ex) {
                    Logger.getLogger(GetDBConnection.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

            return connection;
        }

    }

}
