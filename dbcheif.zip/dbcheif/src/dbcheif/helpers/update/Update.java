/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbcheif.helpers.update;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import dbcheif.exceptions.QueryException;
import dbcheif.helpers.insertion.Insert;
import dbcheif.helpers.insertion.InsertQueryFormer;
import dbcheif.helpers.queryExe.UpdateExecutor;
import dbcheif.interfaces.updator.Updator;
import dbcheif.xtra.DoOut;

/**
 *
 * @author Rashid Iqbal
 */
public class Update implements Updator, UpdateExecutor {

	private final Connection connection;
	private static String query = "";

	private int rowcount;
	private static String pair = "";
	private static String whereValuePair = "";

	@SuppressWarnings("unused")
	private Statement statement;

	public Update(Connection connection) {
		this.rowcount = 0;
		this.connection = connection;
	}

	@Override
	public int update(String table, String key, String value) throws QueryException {
		String token = "";

		if (table.isEmpty() || key.isEmpty()) {
			if (table.isEmpty()) {
				token += "table";
			}
			if (key.isEmpty()) {
				token += "key";
			}

			throw new QueryException(token, "must have some value");
		} else {
			query = "update " + table + " set " + key + " = '" + value + "' ";

			query += ";";

			DoOut.SysOut("query", query);
		}
		return 0;
	}

	@Override
	public int update(String table, String[] key, String[] value) throws QueryException {

		String token = "";

		if (table.isEmpty() || key.length == 0 || value.length == 0) {
			if (table.isEmpty()) {
				token += " table";
			}
			if (key.length == 0) {
				token += " key length";
			}
			if (value.length == 0) {
				token += " value length";
			}

			throw new QueryException(token, "must have some value");
		} else {

			pair = InsertQueryFormer.formKeyValuePairUpdate(key, value);
			query = "update " + table + " set " + pair;

			query += ";";

			DoOut.SysOut("query: ", query);
		}
		return 0;
	}

	@Override
	public int update(String table, String key, String value, String where, String arthmtcOperator, String whereValue)
			throws QueryException {
		String token = "";

		if (table.isEmpty() || key.isEmpty() || where.isEmpty()) {
			if (table.isEmpty()) {
				token += " table";
			}
			if (key.isEmpty()) {
				token += " key";
			}

			if (where.isEmpty()) {
				token += " where";
			}

			throw new QueryException(token, "must have some value");
		} else {
			query = "update " + table + " set " + key + " = '" + value + "' where " + where + " " + arthmtcOperator
					+ " " + whereValue;
			query += ";";
		}
		return 0;
	}

	@Override
	public int update(String table, String[] key, String[] value, String where, String arthmtcOperator,
			String whereValue) throws QueryException {
		String token = "";

		if (table.isEmpty() || key.length == 0 || value.length == 0 || where.isEmpty()) {
			if (table.isEmpty()) {
				token += " table";
			}
			if (key.length == 0) {
				token += " key lenght";
			}
			if (value.length == 0) {
				token += " value length";
			}
			if (where.isEmpty()) {
				token += " where";
			}

			throw new QueryException(token, "must have some value");
		} else {
			pair = InsertQueryFormer.formKeyValuePairUpdate(key, value);
			query = "update " + table + " set " + pair + " where " + where + " " + arthmtcOperator + " '" + whereValue
					+ "'";
			query += ";";

		}
		DoOut.SysOut("query: ", query);
		return 0;
	}

	@Override
	public int update(String table, String key, String value, String[] where, String[] whereValue,
			String arthmtcOperator, String logicalOperator) throws QueryException {
		String token = "";

		if (table.isEmpty() || key.isEmpty() || where.length == 0) {
			if (table.isEmpty()) {
				token += " table";
			}
			if (key.isEmpty()) {
				token += " key";
			}
			if (where.length == 0) {
				token += " where";
			}
			if (whereValue.length == 0) {
				token += " whereValue";
			}
			throw new QueryException(token, "must have some value");
		} else {
			whereValuePair = InsertQueryFormer.formWhereValuePair(where, whereValue, arthmtcOperator, logicalOperator);
			query = "update " + table + " set " + key + " = '" + value + "' where " + whereValuePair;

			query += ";";

			DoOut.SysOut("query", query);
		}
		return 0;
	}

	@Override
	public int update(String table, String[] key, String[] value, String[] where, String[] whereValue,
			String arthmtcOperator, String logicalOperator) throws QueryException {

		String token = "";

		if (table.isEmpty() || key.length == 0 || value.length == 0 || where.length == 0 || whereValue.length == 0) {
			if (table.isEmpty()) {
				token += " table";
			}
			if (key.length == 0) {
				token += " keylength";
			}
			if (value.length == 0) {
				token += " value length";
			}
			if (where.length == 0) {
				token += " where length";
			}
			if (whereValue.length == 0) {
				token += " whereValue length";
			}
			if (arthmtcOperator.isEmpty()) {
				token += "arthmtcOperator";
			}
			if (logicalOperator.isEmpty()) {

				token += "arthmtcOperator";
			}
			throw new QueryException(token, "must must not be 0");
		} else {
			pair = InsertQueryFormer.formKeyValuePairUpdate(key, value);
			whereValuePair = InsertQueryFormer.formWhereValuePair(where, whereValue, arthmtcOperator, logicalOperator);
			query = "update " + table + " set " + pair + " where " + whereValuePair;

			query += ";";

			DoOut.SysOut("query", query);
		}

		return 0;
	}

	@Override
	public int execute() {
		try {
			rowcount = connection.createStatement().executeUpdate(query);
		} catch (SQLException ex) {
			Logger.getLogger(Insert.class.getName()).log(Level.SEVERE, null, ex);
		}
		return rowcount;
	}

}
