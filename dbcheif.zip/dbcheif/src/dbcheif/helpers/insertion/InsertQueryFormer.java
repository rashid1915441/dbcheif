/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbcheif.helpers.insertion;

import dbcheif.exceptions.QueryException;

/**
 *
 * @author Rashid Iqbal
 */
public class InsertQueryFormer {

    /**
     *
     * @param key
     * @param value
     * @return
     * @throws QueryException
     */
    public static String formKeyValuePairInsert(String[] key, String[] value) throws QueryException {

        String keys = "";
        String values = "";
        String keyValuePair = "";
        if (key.length > 0 && value.length > 0) {

            if (key.length == value.length) {

                for (int i = 0; i < key.length; i++) {
                    if (i < key.length - 1 && key.length != 1) {
                        keys += key[i] + ",";
                        values += "'" + value[i] + "'" + ",";
                    } else {
                        keys += key[i];
                        values += "'" + value[i] + "'";
                    }

                }
                keyValuePair += "(" + keys + ") values(" + values + ")";

            } else {
                System.out.println("Insert.formKeyValuePair() key[] and value[] must have same length");
            }
        } else {
            throw new QueryException("key[] and value[]", " must have some values");
        }
        return keyValuePair;
    }

    @SuppressWarnings("unused")
	public static String formKeyValuePairUpdate(String[] key, String[] value) throws QueryException {

        String pair = "";
        String values = "";
        if (key.length > 0 && value.length > 0) {

            if (key.length == value.length) {

                for (int i = 0; i < key.length; i++) {
                    if (i < key.length - 1) {
                        pair += key[i] + " = '" + value[i] + "' ,";
                    } else {
                        pair += key[i] + " = '" + value[i] + "' ";
                    }

                }

            } else {
                System.out.println("Insert.formKeyValuePair() key[] and value[] must have same length");
            }
        } else {
            throw new QueryException("key[] and value[]", " must have some values");
        }
        return pair;
    }

    /**
     *
     * @param where
     * @param whereValue
     * @param arthmtcOperator
     * @param Logicaloperator
     * @return
     * @throws QueryException
     */
    public static String formWhereValuePair(String[] where, String[] whereValue, String arthmtcOperator, String Logicaloperator) throws QueryException {

        String whereValuePair = "";
        if (where.length == where.length) {

            if (where.length == whereValue.length) {
                for (int i = 0; i < where.length; i++) {
                    if (i < (where.length - 1)) {
                        whereValuePair += where[i] + " " + arthmtcOperator + " '" + whereValue[i] + "' " + Logicaloperator + " ";
                    } else {
                        whereValuePair += where[i] + " " + arthmtcOperator + " '" + whereValue[i] + "' ";
                    }

                }

            } else {
                throw new QueryException("where[] and whereValue[]", "must have same length");
            }
        }
        return whereValuePair;

    }
}
