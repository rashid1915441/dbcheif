package dbcheif.helpers.insertion;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import dbcheif.exceptions.QueryException;
import dbcheif.helpers.queryExe.InsertExecutor;
import dbcheif.interfaces.insertor.Insertor;

/**
 *
 * @author Rashid Iqbal
 */
public class Insert implements Insertor, InsertExecutor {

    private final Connection connection;
    private static String query = "";

    @SuppressWarnings("unused")
	private Statement statement;

    public Insert(Connection connection) {
        this.connection = connection;
    }

    public void resetValues() {
        query = "";
        statement = null;
    }

    /**
     *
     * @param table
     * @param key
     * @param value
     * @return
     * @throws QueryException
     */
    @Override
    public void insert(String table, String key, String value) throws QueryException {
      
        if (table.equals("") || key.equals("") || value.equals("")) {
            // TODO error or Throw Exception

            if (table.equals("")) {
                throw new QueryException("table", " name must have some value");
            }
            if (key.equals("")) {
                throw new QueryException("column", " name must not be empty");
            }

            if (value.equals("")) {
                throw new QueryException("value", " must not be empty");
            }

        } else {
            query = "insert into " + table + "(" + key + ") value('" + value + "')";

            query += ";";
        }

    }

    /**
     *
     * @param table
     * @param key
     * @param value
     * @return
     * @throws QueryException
     */
    @Override
    public void insert(String table, String[] key, String[] value) throws QueryException {
 

        @SuppressWarnings("unused")
		String keys = "";
        @SuppressWarnings("unused")
		String values = "";

        String keyValuePair = InsertQueryFormer.formKeyValuePairInsert(key, value);

        query = "insert into " + table + " " + keyValuePair;

        query += ";";

    }

    @Override
    public boolean execute() {

        boolean result = false;
        try {
            result = connection.createStatement().execute(query);
        } catch (SQLException ex) {
            Logger.getLogger(Insert.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

}
