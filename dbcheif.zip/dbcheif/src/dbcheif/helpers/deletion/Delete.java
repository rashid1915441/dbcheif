package dbcheif.helpers.deletion;

import dbcheif.helpers.queryExe.DeleteExecutor;
import dbcheif.interfaces.deletor.Deletor;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
*
* @author Rashid Iqbal
*/
public class Delete implements Deletor, DeleteExecutor {

    @Override
    public int delete(String table, String where, String operator, String whereValue) {
        return 0;
    }

    @Override
    public int delete(String table, String[] where, String operator, String[] whereValue, String logicalOperator) {
        return 0;
    }

    @Override
    public boolean execute() {
        return false;
    }

}
