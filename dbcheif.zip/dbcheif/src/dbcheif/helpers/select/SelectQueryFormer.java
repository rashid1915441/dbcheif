/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbcheif.helpers.select;


/**
 *
 * @author Rashid Iqbal
 */
public class SelectQueryFormer {
    
    private String query = "";
    
    public String select(String target, String table) {
        query = "select " + target + " from " + table;
        return this.query;
    }

    /**
     *
     * @param target
     * @param table
     * @param key
     * @param operator
     * @param value
     * @return
     */
    public String select(String target, String table, String key, String operator, String value) {
        query = "select " + target + " from " + table + " where " + key + " " + operator + " " + value;
        return this.query;
    }

    /**
     *
     * @param target
     * @param table
     * @param keys
     * @param operator
     * @param values
     * @param logicalOperator
     * @return
     */
    public String select(String target, String table, String keys[], String operator,
            String values[], String logicalOperator) {
        
        query = "select " + target + " from " + table + " where " + formKeyValuePair(keys, operator, values, logicalOperator);
        return this.query;
    }
    
    private String formKeyValuePair(String[] keys, String operator, String[] values, String logicalOperator) {
        String pair = "";
        for (int i = 0; i < keys.length; i++) {
            if (i < keys.length - 1) {
                pair += keys[i] + " " + operator + " " + values[i] + " " + logicalOperator + " ";
            } else {
                pair += keys[i] + " " + operator + " " + values[i];
            }
        }
        return pair;
    }
}
