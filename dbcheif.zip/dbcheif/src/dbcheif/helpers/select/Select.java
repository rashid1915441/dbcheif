/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbcheif.helpers.select;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import dbcheif.exceptions.QueryException;
import dbcheif.helpers.queryExe.SelectExecutor;
import dbcheif.interfaces.selector.Selector;


/**
 *
 * @author Rashid Iqbal
 */
public class Select implements Selector, SelectExecutor {

    private Connection connect = null;
    private ResultSet results;
    private String query = "";

    public Select(Connection connect) {
        if (connect != null) {
            this.connect = connect;
        } else {
            //TODO
        }
    }

    @Override
    public ResultSet selectAll(String table) throws QueryException {
        if (table.equals("") || table.equals(null)) {
            throw new QueryException("query error", "need table name");
        } else {
            query = "select * from " + table;
            this.results = this.execute(this.query);
        }
        return this.results;
    }

    @Override
    public ResultSet select(String target, String table) throws QueryException {
        if ((table.equals("") || table.equals(null)) || (target.equals("") || target.equals(null))) {
            if (table.equals("") || table.equals(null)) {
                throw new QueryException("query error", "need table name");
            }
            if (target.equals("") || target.equals(null)) {
                throw new QueryException("query error", "need target columns");
            }
        } else {
            query = "select " + target + " from " + table;
            this.results = this.execute(this.query);
        }
        return this.results;
    }

    @Override
    public ResultSet select(String target, String table, String key, String operator, String value) throws QueryException {
        if ((table.equals("") || table.equals(null)) || (target.equals("") || target.equals(null))
                || (key.equals("") || key.equals(null)) || (operator.equals("") || operator.equals(null))
                || (value.equals("") || value.equals(null))) {
            if (table.equals("") || table.equals(null)) {
                throw new QueryException("query error", "need table name");
            }
            if (target.equals("") || target.equals(null)) {
                throw new QueryException("query error", "need target columns");
            }
            if (key.equals("") || key.equals(null)) {
                throw new QueryException("query error", "predicate column required");
            }
            if (operator.equals("") || operator.equals(null)) {
                throw new QueryException("query error", "relational operator required");
            }
            if (value.equals("") || value.equals(null)) {
                throw new QueryException("query error", "value for predicate is required");
            }
        } else {
            query = "select " + target + " from " + table;
            this.results = this.execute(this.query);
        }
        return this.results;
    }

    @Override
    public ResultSet select(String target, String table, String[] keys, String operator, String[] values) throws QueryException {
        if (keys.length == values.length) {
            if ((values.equals("") || values == null)
                    || (target.equals("") || target == null) || (keys.equals("") || keys == null)
                    || (table.equals("") || table == null) || (operator.equals("") || operator == null)) {

                if (table.equals("") || table == null) {
                    throw new QueryException("query error", "table name needed");
                }
                if (target.equals("") || target == null) {
                    throw new QueryException("query error", "need target columns");
                }

                if (keys.equals("") || keys == null) {
                    throw new QueryException("query error", "predicate column required");
                }
                if (operator.equals("") || operator == null) {
                    throw new QueryException("query error", "relational operator required");
                }
                if (values.equals("") || values == null) {
                    throw new QueryException("query error", "value for predicate is required");
                }
            } else {
                query = "select " + target + " from " + table;
                this.results = this.execute(this.query);
            }
        } else {
            throw new QueryException("query error", "keys and values must have same length");
        }
        return this.results;
    }

    @Override
    public ResultSet execute(String query) {
        try {
            if (query.equals("") || query != null) {
                this.results = this.connect.createStatement().executeQuery(query);
            }

        } catch (SQLException ex) {
            Logger.getLogger(Select.class.getName()).log(Level.SEVERE, null, ex);
        }
        return this.results;
    }

}
