/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbcheif;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import dbcheif.exceptions.QueryException;
import dbcheif.helpers.connection.GetDBConnection;
import dbcheif.helpers.select.Select;
import dbcheif.xtra.DoOut;


/**
 *
 * @author Rashid Iqbal
 */
public class Examples {

    /**
     * @param args the command line arguments
     */
    private static Connection connection;

    public static void main(String[] args) throws QueryException {

        try {
            connection = GetDBConnection.get("localhost", "3306", "db", "dbuser", "")
                    ;
            if (connection != null) {
                DoOut.SysOut("connected", "DB Connection Successfull");
            }

            Select select = new Select(connection);
            
            ResultSet rs = select.select("password", "test", new String[]{"username", "email"}, "=", new String[]{"mujahidh360",
                "mujahidh360@gmail.com"});
            while (rs.next()) {
                DoOut.SysOut("ResultSet", rs.getString("password"));
            }

            /**
             * Insert Example 
             */
//        Insert insert = new Insert(connection);
//        insert.insert("test", new String[]{"username", "email", "password"},
//                new String[]{"rashid", "rashid@rashid.com", "password"});
//        boolean result = insert.execute();
//        if (!result) {
//            DoOut.SysOut("Insert", "Data added Successfully");
//        }
//        Update update = new Update(connection);
//        update.update("test", new String[]{"email"},
//                new String[]{"rashid1915541@gmail.com"}, "username", "rashid", "=");
//        update.execute();
//
//        update.update("test", "username", "rashidiqbal");
//        update.execute();
//
//        update.update("test", "email", "rashid1915441@gmail.com", new String[]{"username", "email"},
//                new String[]{"rashid1915541", "rashid1915541@gmail.com"}, "=", "OR");
//        update.execute();
//
//        update.update("test", new String[]{"username", "email"}, new String[]{"rashid1915541", "rashid1122@gmail.com"},
//                "password", "=", "password");
//        update.execute();
//        update.update("test",
//                new String[]{"key1", "key2", "key2"}, new String[]{"value1", "value2", "value2"},
//                new String[]{"whereValue1", "whereValue2", "whereValue3"},
//                new String[]{"whereValue1", "whereValue2", "whereValue3"}, "=", "OR");
        } catch (SQLException ex) {
            Logger.getLogger(Examples.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
