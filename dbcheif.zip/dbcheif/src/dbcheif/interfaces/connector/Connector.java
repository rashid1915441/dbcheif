package dbcheif.interfaces.connector;

import java.sql.Connection;

import dbcheif.interfaces.ChildGetter;
/**
*
* @author Rashid Iqbal
*/
public interface Connector extends ChildGetter<Object> {
 
    /**
     *
     * @param host
     * @param port
     * @param db
     * @param dbuser
     * @param dbpassword
     * @return
     */
    public Connection getDbConnection(String host, String port, String db, String dbuser, String dbpassword);

}