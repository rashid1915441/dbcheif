package dbcheif.interfaces.selector;

import java.sql.ResultSet;

import dbcheif.exceptions.QueryException;

/**
 *
 * @author Rashid Iqbal
 */
public interface Selector {

    /**
     *
     * @param table
     * @return
     * @throws mydbframework.exceptions.QueryException
     */
    public ResultSet selectAll(String table) throws QueryException;

    /**
     *
     * @param target
     * @param table
     * @return
     * @throws mydbframework.exceptions.QueryException
     */
    public ResultSet select(String target, String table) throws QueryException;

    /**
     *
     * @param target
     * @param table
     * @param where
     * @param operator
     * @param whereValue
     * @return
     * @throws mydbframework.exceptions.QueryException
     */
    public ResultSet select(String target, String table, String where, String operator, String whereValue) throws QueryException;

    /**
     *
     * @param target
     * @param table
     * @param where
     * @param operator
     * @param whereValue
     * @return
     * @throws mydbframework.exceptions.QueryException
     */
    public ResultSet select(String target, String table, String where[], String operator, String whereValue[]) throws QueryException;
 
}
