package dbcheif.interfaces.insertor;

import dbcheif.exceptions.QueryException;

/**
 *
 * @author Rashid Iqbal
 */
public interface Insertor {

    /**
     *
     * @param table
     * @param key
     * @param value
     * @return
     * @throws QueryException
     */
    public void insert(String table, String key, String value) throws QueryException;

    /**
     *
     * @param table
     * @param key
     * @param value
     * @return
     * @throws QueryException
     */
    public void insert(String table, String key[], String value[]) throws QueryException;

}
