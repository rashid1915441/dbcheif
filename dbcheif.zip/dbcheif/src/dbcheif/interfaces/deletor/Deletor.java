package dbcheif.interfaces.deletor;

/**
 *
 * @author Rashid Iqbal
 */
public interface Deletor {

    /**
     *
     * @param table
     * @param where
     * @param operator
     * @param whereValue
     * @return
     */
    public int delete(String table, String where, String operator, String whereValue);

    /**
     *
     * @param table
     * @param where
     * @param operator
     * @param whereValue
     * @param logicalOperator
     * @return
     */
    public int delete(String table, String where[], String operator, String whereValue[], String logicalOperator);

}
