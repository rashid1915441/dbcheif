package dbcheif.interfaces;

/**
 *
 * @author Rashid Iqbal
 */
public interface ChildGetter<T> { 

    /**
     *
     * @return
     */
    public T getInstance(); 
	
}