package dbcheif.interfaces.updator;

import dbcheif.exceptions.QueryException;
/**
*
* @author Rashid Iqbal
*/
public interface Updator {

    /**
     *
     * @param table
     * @param key
     * @param value
     * @return
     * @throws QueryException
     */
    public int update(String table, String key, String value) throws QueryException;

    /**
     *
     * @param table
     * @param key
     * @param value
     * @return
     * @throws QueryException
     */
    public int update(String table, String key[], String value[]) throws QueryException;

    /**
     *
     * @param table
     * @param key
     * @param value
     * @param where
     * @param whereValue
     * @param arthmtcOperator
     * @return
     * @throws QueryException
     */
    public int update(String table, String[] key, String[] value, String where, String whereValue,
            String arthmtcOperator) throws QueryException;

    /**
     *
     * @param table
     * @param key
     * @param value
     * @param where
     * @param whereValue
     * @param arthmtcOperator
     * @return
     * @throws QueryException
     */
    public int update(String table, String key, String value, String where, String whereValue, String arthmtcOperator) throws QueryException;

    /**
     *
     * @param table
     * @param key
     * @param value
     * @param where
     * @param whereValue
     * @param arthmtcOperator
     * @param logicalOperator
     * @return
     * @throws QueryException
     */
    public int update(String table, String key, String value, String where[], String whereValue[], String arthmtcOperator, String logicalOperator) throws QueryException;

    /**
     *
     * @param table
     * @param key
     * @param value
     * @param where
     * @param whereValue
     * @param arthmtcOperator
     * @param logicalOperator
     * @return
     * @throws QueryException
     */
    public int update(String table, String key[], String value[], String where[], String whereValue[], String arthmtcOperator, String logicalOperator) throws QueryException;

}
