/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbcheif.xtra;

/**
 *
 * @author Rashid Iqbal
 */

public class DoOut {

    /**
     *
     * @param caution
     * @param value
     */
    public static final void SysOut(String caution, String value) {
        System.out.println(caution + ": " + value);
    }
}
