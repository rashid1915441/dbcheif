/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbcheif;

import java.sql.Connection;
import dbcheif.helpers.connection.GetDBConnection;


/**
 *
 * @author Rashid Iqbal
 */
public class Configs {

    public static final Connection connection = GetDBConnection.get("localhost", "3306", "db", "dbuser", "");

}
